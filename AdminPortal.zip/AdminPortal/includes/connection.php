<?php 

    $con = mysqli_connect('localhost', 'root', '', 'AdminPortal_System');

    if(!$con)
        {
            echo ' Connection Error ';
        }

?>