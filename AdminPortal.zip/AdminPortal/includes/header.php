<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Mono|VT323" rel="stylesheet">
    <title>University of Houston Portal</title>
</head>
<body style="background:#c8102e">

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm bg-danger navbar-dark">
        <div class="container">
            <button class="navbar-toggler" data-toggle="collapse" data-target="#Navbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a href="index.php" class="navbar-brand"><h1>University of Houston</h1></a>
            <div class="collapse navbar-collapse" id="Navbar" >
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <?php 
                            if(isset($_SESSION['EmployeeID']) || isset($_SESSION['admin'] || isset($_SESSION['manager']))
                            {
                                echo '<form action="logout.php" method="POST">
                                <button class="btn btn-link text-secondary" name="logout">LOGOUT</button>
                                </form>';
                            }
                            else
                            {
                                echo '<a href="login.php" class="nav-link">LOGIN</a>';
                            }

                        ?>
                        
                    </li>
                </ul>
            </div>
        </div>
    </nav>

