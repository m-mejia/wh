<?php
require_once('includes/header.php');
require_once('includes/connection.php');
require_once('includes/function.php');

if(isset($_SESSION['EmployeeID']) || isset($_SESSION['manager']))
{
    $_SESSION['GET'] = $GetID = $_GET['Success'];
    $query = "SELECT * FROM EMPLOYEE_DATA WHERE ID = '".$GetID."'";
    $result = mysqli_query($con, $query);
    
    while($row = mysqli_fetch_assoc($result))
    {
        $Fname = $row['fname'];
        $Lname = $row['lname'];
        $Title = $row['title'];
        $Hours = $row['hours'];
        $Date = $row['date'];
    }
    
}
require_once('includes/footer.php');
?>

<div class="container">
    <div class="row">
        <div class="col">
            <div class="card bg-dark text-white mt-3">
                <h4 class="text-center py-3 mt-2">Approve Hours for <?php echo $Fname." ".$Lname ?></h4>
            </div>
        </div>
    </div>

    <?php

        if(isset($_SESSION['manager']) || $_SESSION['GET'] == $_SESSION['EmployeeID'])
        {
        
    ?>

    <div class="row">
        <div class="col-lg-3">
            <div class="card mt-3">
                <div class="card-title bg-info py-2 rounded-top rounded-bottom">
                    <p class="text-center m-2 text-white">Control Panel </p>
                </div>
    
                <tr>
                <td> <a href="approved.php" class="btn btn-outline-primary btn-sm"> Approve Hours </a> </td>
                <td> <a href="disapproved.php" class="btn btn-outline-danger btn-sm mt-2"> Disapprove Hours </a> </td>
                </tr>


                <div class="card mt-2"> 
                <div class="card-title bg-warning text-black rounded-top rounded-bottom">
                    <p class="text-center m-2"> <small> NOTE: If employee has less than 20 hours or more than 40 hours per two week cycle: DISAPPROVE </small></p>
                </div>
                </div>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="card mt-3">
                <table class="table table-dark table-hover">
                    
                    <tr>
                        <th>Employee Name</th>
                        <td><?php echo $Fname." ".$Lname ?></td>
                    </tr>
                    <tr>
                        <th>Employee Title</th>
                        <td><?php echo $Title ?></td>
                    </tr>
                    <tr> 
                        <th> Hours Worked </th>
                        <td><?php echo $Hours ?> </td>
                    </tr>
                        
                </table>
            </div>
        </div>
    </div>
    
<?php 
    }
    else
    {
        $Error = "Something is wrong";
        echo '<div class="alert alert-danger text-center">'.$Error.'</div>';
    }
    
?>
</div>
