Michelle Mejia and Andre Gil 
COSC 4351
University of Houston Company Portal 

This application was built using the LAMP stack (Linux, Apache, MySQL, PHP) and the Bootstrap framework for a stylish and responsive UI. In the zipped AdminPortal folder, the database is "AdminPortal_System". 

There are 3 roles with distinct functions exclusive to their own:
    Employee - Employees are able to see their personal details like Username, Email, Job Title, and Hours. Employees can also register themselves.
    Manager - Manager can see their own personal details, their employees, and approve or disapprove employee hours. 
    (If employee has worked more than 40 hours or less than 20 hours disapprove; otherwise approve)
    Admin - Admins are able to see everyone's personal details, can search employees, and delete employees. Admins can also register an employee. 

LOGIN INFORMATION:
    Employee Username: GetZucced
    Employee Password: 123

    Manager Username: Michelle
    Manager Password: 123

    Admin Username: AdminBoi
    Admin Password: 123

^Clearly, in a real-world setting this login information would be horrible. The password created from the user 
is hashed stored securely in the database. 

