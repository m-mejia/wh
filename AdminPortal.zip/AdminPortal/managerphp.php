<?php
    session_start();
    require_once('includes/connection.php');
    if(isset($_POST['login']))
    {
        if(empty($_POST['username']) || empty($_POST['password']))
        {
            header("location:manager_login.php?empty");
        }
        else
        {
            $MGname = mysqli_real_escape_string($con, $_POST['username']);
            $MGPass = mysqli_real_escape_string($con, $_POST['password']);

            $query = "SELECT * FROM Manager_Data WHERE MGName = '".$MGname."' AND MGPass = MD5('".$MGPass."')";
            $result = mysqli_query($con, $query);

            if($row=mysqli_fetch_assoc($result))
            {
                $_SESSION['manager'] = $row['MGName'];
                header("location:manager_portal.php");
            }
            else
            {
                header("location:admin_login.php?manager_invalid");
            }
        }
    }
    else
    {
        header("location:manager_login.php");
    }

?>