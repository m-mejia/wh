<?php
require_once('includes/header.php'); 
require_once('includes/connection.php');

    if(isset($_POST['find']))
    {
        $search = $_POST['search'];
        $query = "SELECT * FROM Employee_Data WHERE uname = '".$search."' OR email = '".$search."'";
        $result = mysqli_query($con, $query);
    }
    else
    {
        header("location:admin_login.php");
    }

    echo ' <div class="container">
    <div class="row">
        <div class="col">
            <div class="card bg-dark text-white mt-5">
                <h2 class="text-center py-3 mt-2"> Admin Portal </h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-title">
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <form action="search.php" method="POST">
                                    <div class="form-inline float-right">
                                        <input type="text" placeholder="Search Records" class="form-control" name="search">
                                        <button class="btn btn-success" name="find"> Search </button>
                                    </div>
                                </form>
                            </tr>
                            <tr class="bg-info text-white">
                                <td> Employee ID </td>
                                <td> Employee Image </td>
                                <td> Employee Name </td>
                                <td> Employee Title </td>
                                <td> Employee Email </td>
                                <td colspan="7"> Operations </td>
                            </tr> ';
?>

                            <?php

                            while($row = mysqli_fetch_assoc($result))
                            {
                                $EmpID = $row['ID'];
                                $EmpImage = $row['img'];
                                $EmpFname = $row['fname'];
                                $EmpLname = $row['lname'];
                                $EmpTitle = $row['title'];
                                $EmpEmail = $row['email'];

                            ?>

                            <tr>
                                <td> <?php echo $EmpID ?> </td>
                                <td> <img src="data:image/jpg;base64,<?php echo base64_encode($EmpImage);  ?>" width="50" height="50" class="img-thumbnail" /> </td>
                                <td> <?php echo $EmpFname ." ". $EmpLname ?> </td>
                                <td> <?php echo $EmpTitle ?> </td>
                                <td> <?php echo $EmpEmail ?> </td>
                                <td> <a href="view.php?Success=<?php echo $EmpID ?>" class="btn btn-dark btn-sm"> View </a> </td>
                                <!-- <td> <a href="admin_edit.php?edit=" class="btn btn-secondary btn-sm"> Edit </a> </td> -->
                                <td> <a href="delete.php?del=<?php echo $EmpID ?>" class="btn btn-danger btn-sm"> Delete </a> </td>
                            </tr>

                            <?php } ?>
                            
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php require_once('includes/footer.php'); ?>



