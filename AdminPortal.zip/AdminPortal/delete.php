<?php
    require_once('includes/connection.php');
    if(isset($_GET['del']))
    {
        $DelID = $_GET['del'];
        $query = "SELECT * FROM Employee_Data WHERE ID = '".$DelID."'";
        $result = mysqli_query($con, $query);

        while($row = mysqli_fetch_assoc($result))
            
        $Delquery = "DELETE FROM Employee_Data WHERE ID = '".$DelID."'";
        $resultquery = mysqli_query($con, $Delquery);

        if($resultquery)
        {
            header("location: admin_portal.php");
        }
        else
        {
            echo 'Something went wrong! :(';
        }
    }
?>
