<?php require_once('includes/header.php'); ?>

<div class="container">
    <div class="row">
        <div class="card mt-5 bg-danger h-100" style="width: 32rem;">
            <div>
                <img src="images/uofh1.jpg" width="550" height="500" class="d-flex m-auto">
            </div>
        </div>
        <div class="col">
            <div class="card ml-auto mt-5 bg-danger" style="width: 32rem;">
                <div class="card-title">
                    <pre> <h3 class="display-3 text-center bg-danger text-light text-secondary mt-3"><font size='5'>University of Houston Portal</font></h3>
                        <h3 class="text-center text-warning mt-9"> Welcome to the University of Houston! </h3>

                    </pre>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('includes/footer.php'); ?>
