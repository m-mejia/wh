<?php 
    require_once('includes/connection.php');
    if(isset($_POST['register']))
    {
        $Image = $_FILES['image']['name'];
        $Type = $_FILES['image']['type'];
        $Temp = $_FILES['image']['tmp_name'];
        $Size = $_FILES['image']['size'];
        
        $Ext = explode('.', $Image);
        $TrueExt = (strtolower(end($Ext)));
        $AllowImg = array('jpg');
        $Target = "images/".$Image;
        
        $FirstName = mysqli_real_escape_string($con, $_POST['Fname']);
        $LastName = mysqli_real_escape_string($con, $_POST['Lname']);
        $DOB = mysqli_real_escape_string($con, $_POST['DOB']);
        $Gender = mysqli_real_escape_string($con, $_POST['gender']);
        $Email = mysqli_real_escape_string($con, $_POST['email']);
        $Username = mysqli_real_escape_string($con, $_POST['Uname']);
        $Password = mysqli_real_escape_string($con, $_POST['password']);
        $Title = mysqli_real_escape_string($con, $_POST['title']);

        echo $FirstName." ".$LastName." ".$DOB." ".$Gender." ".$Email." ".$Username." ".$Password." ".$Title;

        if(empty($Image) || empty($FirstName) || empty($LastName) || empty($DOB) || empty($Gender) || empty($Email) || empty($Username) || empty($Password) || empty($Title))
        {
            header("location: register.php?Empty");
            exit();
        }
        else
        {
            if (!preg_match("/^[a-z, A-Z]*$/",$FirstName) || !preg_match("/^[a-z, A-Z]*$/",$LastName) || !preg_match("/^[a-z, A-Z]*$/",$UserName))
        {
            header("location: register.php?characters");
            exit();
        }
        else
        {
            if(!filter_var($Email, FILTER_VALIDATE_EMAIL))
            {
                header("location: register.php?ValidEmail");
                exit();
            }
            else
            {
                $query = "SELECT * FROM Employee_Data WHERE Uname='".$Username."'";
                $result = mysqli_query($con, $query);

                if(mysqli_fetch_assoc($result))
                {
                    header("location: register.php?UserTaken");
                    exit();
                }
                else 
                {
                    $query = "SELECT * FROM Employee_Data WHERE email='".$Email."'";
                    $result = mysqli_query($con, $query);

                    if(mysqli_fetch_assoc($result))
                    {
                        header("location: register.php?EmailTaken");
                        exit();
                    }
                    else
                    {
                        // We hash the passwords for security 
                        $HashPass = password_hash($Password, PASSWORD_DEFAULT);
                        date_default_timezone_get("America/Chicago"); // since Texas is in CST
                        $date = date("d/m/Y");
                    }
                    if(in_array($TrueExt, $AllowImg))
                        {
                            
                            if($size < 1000000)
                            {
                                $query = "INSERT INTO Employee_Data (img, fname, lname, dob, gender, email, uname, password, title, date) VALUES ('$Image', '$FirstName', '$LastName', '$DOB', '$Gender', '$Email','$Username', '$HashPass', '$Title', '$date')";
                                $result = mysqli_query($con, $query);
                                move_uploaded_file($Temp, $Target);
                                header("location: register.php?Success");
                                exit();
                            }
                            else
                            {
                                header("location: register.php?Too_Large");
                                exit();
                            }
                        }
                        else
                        {
                            header("location: register.php?Invalid_Format");
                            exit();
                    }
                }
            } 
        }
    }
}

?>
