<?php 
require_once('includes/header.php');
require_once('includes/function.php');
 ?>

    <div class="container">
        <div class="row">
            <div class="card mt-5 bg-danger h-100" style="width: 32rem;">
            <div>
                <img src="images/uofh3.jpg" width="550" height="500" class="d-flex m-auto">
            </div>
        </div>
            <div class="col-lg-6 m-auto">
                <div class="mt-5">
                    <img src="images/admin.jpg" width="150" height="150" class="d-flex m-auto">     
                </div>
                    <div class="card mt-2">
                        <div class="card-title bg-secondary rounded-top rounded-bottom">
                            <h2 class="text-center text-white py-3 mt-1">Admin Login</h2>
                    </div>

                    <?php
                        $Message = "";

                        if(isset($_GET['empty']))
                        {
                            $Message = "Please fill in the blanks";
                            echo '<div class="alert alert-danger text-center">'.$Message.'</div>';
                        }

                        if(isset($_GET['admin_invalid']))
                        {
                            $Message = "Admin Login is invalid";
                            echo '<div class="alert alert-danger text-center">'.$Message.'</div>';
                        }

                        if(isset($_SESSION['admin']))
                        {
                            header("location: admin_portal.php");
                        }
                    ?>

                    <div class="card-body text-center">
                        <form action="adminphp.php" method="POST">
                            <input type="text" placeholder=" Username " name="username" classname="form-control mb-5">
                            <input type="password" placeholder=" Password " name="password" classname="form-control mb-5">
                            <button class="btn btn-success mt-3" name="login">Login Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 

<?php require_once('includes/footer.php'); ?>
