<?php
require_once('includes/header.php'); 
require_once('includes/connection.php');

    if(isset($_SESSION['manager']))
    {
        $query = "SELECT * FROM Employee_Data";
        $result = mysqli_query($con, $query);
    }
    else
    {
        header("location:manager_login.php");
    }

?>

    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card bg-dark text-white mt-5">
                    <h2 class="text-center py-3 mt-2"> Manager Portal </h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-title">
                        <div class="card-body">
                            <table class="table table-striped">
                                
                                <tr class="bg-info text-white">
                                    <td> Employee ID </td>
                                    <td> Employee Image </td>
                                    <td> Employee Name </td>
                                    <td> Employee Email </td>
                                    <td> Employee Title </td>
                                    <td colspan="7"> Operations </td>
                                </tr>

                            <?php

                            while($row = mysqli_fetch_assoc($result))
                            {
                                $EmpID = $row['ID'];
                                $EmpImage = $row['img'];
                                $EmpFname = $row['fname'];
                                $EmpLname = $row['lname'];
                                $EmpEmail = $row['email'];
                                $EmpTitle = $row['title'];

                            ?>
                            <tr>
                                <td> <?php echo $EmpID ?> </td>
                                <td> <img src="data:image/jpg;base64,<?php echo base64_encode($EmpImage);  ?>" width="50" height="50" class="img-thumbnail" /> </td>
                                <td> <?php echo $EmpFname ." ". $EmpLname ?> </td> 
                                <td> <?php echo $EmpEmail ?> </td>
                                <td> <?php echo $EmpTitle ?> </td>
                                <td> <a href="approve.php?Success=<?php echo $EmpID ?>" class="btn btn-dark btn-sm"> Approve Hours </a> </td>
                            </tr>

                            <?php } ?>
                            
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php require_once('includes/footer.php'); ?>


