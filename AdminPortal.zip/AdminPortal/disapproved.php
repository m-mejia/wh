<?php require_once('includes/header.php'); ?>

<div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                    <div class="card-title bg-danger rounded-top mt-5">
                        <h2 class="text-center text-white py-3 mt-1"> You have disapproved the hours </h2>
                    </div>
            </div>
        </div>
            <div class="text-center"> 
                <button class="btn btn-white mt-3" name="login"><?php echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>"; ?> </button>  
            </div>
    </div>




