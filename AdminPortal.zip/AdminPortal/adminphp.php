<?php
    session_start();
    require_once('includes/connection.php');
    if(isset($_POST['login']))
    {
        if(empty($_POST['username']) || empty($_POST['password']))
        {
            header("location:admin_login.php?empty");
        }
        else
        {
            $Aname = mysqli_real_escape_string($con, $_POST['username']);
            $Pass = mysqli_real_escape_string($con, $_POST['password']);

            $query = "SELECT * FROM Admin_Data WHERE AdminName = '".$Aname."' AND AdminPass = MD5('".$Pass."')";
            $result = mysqli_query($con, $query);

            if($row=mysqli_fetch_assoc($result))
            {
                $_SESSION['admin'] = $row['AdminName'];
                header("location:admin_portal.php");
            }
            else
            {
                header("location:admin_login.php?admin_invalid");
            }
        }
    }
    else
    {
        header("location:admin_login.php");
    }

?>